﻿$ScriptPath = 'C:\poshbot\poshbot-script.ps1'

$ServiceName = 'poshbot'

$ServicePath = 'C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe'

$ServiceArguments = '-ExecutionPolicy Bypass -NoProfile -File "{0}"' -f $ScriptPath

#Import-Module poshbot -force

C:\poshbot\nssm.exe install $ServiceName $ServicePath $ServiceArguments
Start-Sleep -Seconds .5

# check the status... should be stopped
C:\poshbot\nssm.exe status $ServiceName

# start things up!
C:\poshbot\nssm.exe start $ServiceName

# verify it's running
C:\poshbot\nssm.exe status $ServiceName